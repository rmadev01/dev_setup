-- options
vim.o.number = true
vim.o.relativenumber = true
vim.o.undofile = true
vim.o.ignorecase = true
vim.o.smartcase = true
vim.o.cursorline = true
vim.o.splitright = true
vim.o.splitbelow = true
vim.o.wrap = false
vim.o.swapfile = false
vim.o.tabstop = 4
vim.o.shiftwidth = 4
vim.o.expandtab = true
vim.scrolloff = 10
vim.g.mapleader = " "
vim.o.signcolumn = "yes"
vim.o.winborder = "rounded"
vim.o.updatetime = 250
vim.o.timeoutlen = 300

-- basic keymaps
vim.keymap.set("i", "jj", "<ESC>")
vim.keymap.set("n", "<leader>w", ":write<CR>")
vim.keymap.set("n", "<leader>q", ":quit<CR>")

-- window navigation
vim.keymap.set("n", "<C-h>", "<C-w>h")
vim.keymap.set("n", "<C-l>", "<C-w>l")

-- splits
vim.keymap.set("n", "<leader>sr", ":vsplit<CR>")
vim.keymap.set("n", "<leader>se", "<C-w>=")

-- custom resize logic
local function resize_left(n)
  local current = vim.api.nvim_get_current_win()
  vim.cmd("wincmd h | vertical resize " .. (n > 0 and "+" or "") .. n)
  vim.api.nvim_set_current_win(current)
end
vim.keymap.set("n", "<C-Left>", function() resize_left(-5) end)
vim.keymap.set("n", "<C-Right>", function() resize_left(5) end )

-- plugins
vim.pack.add({
	{ src = "https://github.com/vague2k/vague.nvim"},
	{ src = "https://github.com/stevearc/oil.nvim" },
	{ src = "https://github.com/echasnovski/mini.pick" },
	{ src = "https://github.com/mason-org/mason.nvim" },
	{ src = "https://github.com/neovim/nvim-lspconfig" },
})

-- colorscheme
vim.cmd("colorscheme vague")
vim.cmd(":hi statusline guibg=NONE")

-- oil
require("oil").setup({ keymaps = { ["."] = "actions.toggle_hidden" } })
vim.keymap.set("n", "<leader>e", ":Oil<CR>")

-- mini.pick
require("mini.pick").setup()
vim.keymap.set("n", "<leader>f", ":Pick files<CR>")
vim.keymap.set("n", "<leader>h", ":Pick help<CR>")
vim.keymap.set("n", "<leader>g", ":Pick grep_live<CR>")
vim.keymap.set("n", "<leader>b", ":Pick buffers<CR>")

-- lsp
require("mason").setup()
vim.lsp.enable({ "lua_ls", "rust_analyzer", "pyright", "ruff", "clangd", "stylua" })

-- lsp keymaps
vim.keymap.set("n", "gd", vim.lsp.buf.definition)
vim.keymap.set("n", "gr", vim.lsp.buf.references)
vim.keymap.set("n", "K", vim.lsp.buf.hover)
vim.keymap.set("n", "<leader>ca", vim.lsp.buf.code_action)
vim.keymap.set("n", "<leader>rn", vim.lsp.buf.rename)
vim.keymap.set("n", "<leader>lf", vim.lsp.buf.format)

-- lsp completions
vim.api.nvim_create_autocmd("LspAttach", {
	group = vim.api.nvim_create_augroup("my.lsp", {}),
	callback = function(args)
		local client = assert(vim.lsp.get_client_by_id(args.data.client_id))
		if client:supports_method("textDocument/completion") then
			local chars = {}
			for i = 32, 126 do
				table.insert(chars, string.char(i))
			end
			client.server_capabilities.completionProvider.triggerCharacters = chars
			vim.lsp.completion.enable(true, client.id, args.buf, { autotrigger = true })
		end
	end,
})
vim.cmd([[set completeopt+=menuone,noselect,popup]])

-- highlight on yank
vim.api.nvim_create_autocmd("TextYankPost", {
	group = vim.api.nvim_create_augroup("highlight_yank", {}),
	callback = function()
		vim.highlight.on_yank()
	end,
})

-- return to last position
vim.api.nvim_create_autocmd("BufReadPost", {
	group = vim.api.nvim_create_augroup("last_position", {}),
	callback = function()
		local mark = vim.api.nvim_buf_get_mark(0, '"')
		local lcount = vim.api.nvim_buf_line_count(0)
		local line = mark[1]
		local ft = vim.bo.filetype
		if line > 0 and line <= lcount
			and vim.fn.index({ "commit", "gitrebase", "xxd" }, ft) == -1
			and not vim.o.diff
		then
			pcall(vim.api.nvim_win_set_cursor, 0, mark)
		end
	end,
})

-- clipboard sync
vim.schedule(function()
  vim.o.clipboard = 'unnamedplus'
end)
